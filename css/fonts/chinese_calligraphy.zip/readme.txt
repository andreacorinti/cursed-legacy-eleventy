Congratulations!  You have downloaded one of my fonts.

You can use it for anything -- although, if you use it for something arty, I'd like to see it.

Don't redistribute it, though, or claim it as yours...I'll come after you!!!  Yes.

Have fun!
Jessie
macilwen1@yahoo.com (no hatemail, please)